import {Component } from 'angular2/core';

@Component({
  selector: 'home',
  template: '<h1>Ng Component Not Found</h1>'
})
export class Unknown {
  title = 'app works!';
} 