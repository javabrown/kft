import {Component } from 'angular2/core';
 
@Component({
	selector: 'tree',
	template: '<h1>Hello {{a}}</h1>'
})

export class Tree {
    a : "Hello TreeA";
	
	 
};