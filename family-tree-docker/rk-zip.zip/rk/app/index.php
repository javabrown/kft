<?php 
          require('../../../wp-blog-header.php');
		  include('../../../wp-content/themes/hestia/header.php'); ///wp-content/themes/hestia
		  //get_header();
?> 
 
   <!-- link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script -->
 
 <br/>
  
    <div class="panel-body tree-view">
		 
        <title>Family Tree</title>
		<script type="text/javascript" src="http://d3js.org/d3.v3.js"></script>
		<!-- script src="js/d3.js"></script -->
		
        <!-- script src="js/main.js"></script -->
     
		 <link rel="stylesheet" type="text/css" href="css/style.css">
         <script src="js/main.js"></script>
		 
		<script type="text/javascript">     
 
        </script>
        
    </div>
		
 
 
    
 
 <?php get_footer(); ?>