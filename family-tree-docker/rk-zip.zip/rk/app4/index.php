 <?php 
          require('../../../wp-blog-header.php');
		  include('../../../wp-content/themes/hestia/header.php'); ///wp-content/themes/hestia
		  get_header();
?> 
 
   

    <body1>

   <script src="http://d3js.org/d3.v3.min.js"></script>
 
	<link type="text/css" rel="stylesheet" href="css/style.css">
	
    <script src="js/main.js"></script>
	
	<div id="tree">

    </div>
	
    </body1>
    
 
 <?php get_footer(); ?>